# KaiMau CHANG（張凱貿）

**Director | Technology Strategy, Scouting & Systems Architecture**

Taipei, Taiwan | kelvin820@gmail.com | https://www.linkedin.com/in/changkaimau/ | https://kelvin820.github.io

## Professional profile

Technology strategy and scouting leader with 20+ years spanning mobile RF engineering, Tier-1 customer programs, internal innovation and technology roadmapping. Brings learning agility across unfamiliar architectures, hands-on prototype validation and high-level pathfinding to Personal AI Hubs, edge systems and Buy-then-Build partnerships.

## Core competencies

- Technology strategy & roadmapping
- Technology scouting & due diligence
- Personal AI hubs / edge systems
- RF, wireless & spatial sensing
- Systems architecture & prototyping
- Tier-1 customer delivery / NPI
- Hypothesis-driven PoC
- Buy-then-Build partnerships
- Learning agility & adaptability

## Professional experience

### XUNWEI Technologies Co. Ltd.

**Director | Technology Scouting and R&D Partnerships** | Jan 2020 — Present

*Technology direction & strategic execution*

- Led forward-looking technology scouting, competitive insight and roadmap planning for smart terminals, wearables and distributed edge sensing.
- Qualified external optical-sensing partners and completed a 2-month clinical PoC; delivered a biometric feature in under 8 months against a 24-month internal R&D plan.
- Planned a Buy-then-Build path with a 2-year proprietary R&D runway; worked with procurement and legal on regional exclusivity and balanced partnership terms.
- Used project-specific decision gates, pre-planned test hypotheses and cross-functional PM/engineering alignment to assess architecture trade-offs and R&D commitments.

### Huawei Technologies

**Technology Sourcing and Planning** | Jan 2018 — Jan 2020

*Broader insight & technology pathfinding*

- Broadened technology scanning across adjacent domains, turning industry signals into higher-level technical insights.
- Explored alternative technical paths and contributed to technology direction and roadmap planning beyond a single platform or product.

### MediaTek

**Technical Manager** | Sep 2014 — Jan 2018

*Internal innovation, from architecture to prototype*

- Developed internal innovation from system architecture analysis and technology identification through prototype implementation.
- Explored VR/HMD technologies across optics, ergonomics, ultrasound/ToF hand tracking, eye tracking and electromagnetic position tracking.
- Explored autonomous-vehicle architectures, sensing, drive-by-wire, datasets, simulation and data visualization.
- Co-inventor on U.S. patent US9791924B2, filed during my MediaTek tenure; listed in the inventor record as Kai-Mau Chang.

### Foxconn

**Senior EE/RF Engineer** | Apr 2009 — Sep 2014

*Tier-1 customer delivery & factory NPI*

- Supported Tier-1 customer programs for Dell, HP, Sony and Nintendo, developing customer-facing engineering and cross-functional coordination.
- Provided on-site factory NPI support for Apple customer programs.
- Worked across notebooks, netbooks, tablets, WLAN/Bluetooth modules, 60 GHz WiHD and NVIDIA LTE M.2 products.

### Compal

**Senior RF Engineer** | Aug 2006 — Apr 2009

*Learning agility & adaptability*

- Quickly learned and ramped up on TI, EMP and Qualcomm GSM/WCDMA platforms by finding common engineering principles and adapting to the differences in each architecture.
- Across my Compal roles, supported Motorola and strengthened customer-facing technical communication and the ability to apply prior learning in unfamiliar technical contexts.

### Compal

**RF Design Engineer** | Aug 2004 — Aug 2006

*RF engineering foundations*

- Worked on WCDMA mobile-phone RF design on the EMP platform, establishing hardware foundations for rapid learning in unfamiliar architectures and later system-level work.

## Education

**National Chung Cheng University** | 2003 — 2004

Master’s degree · Electrical Engineering

RF device research and development.

Graduate IC design work included a dual-band Wi-Fi low-noise amplifier (LNA). Received high marks in multiple graduate IC tape-out evaluations.

## Patent

**US9791924B2** | Co-inventor

Filed during my MediaTek tenure; the inventor record lists me as Kai-Mau Chang.

https://patents.google.com/patent/US9791924B2/en
