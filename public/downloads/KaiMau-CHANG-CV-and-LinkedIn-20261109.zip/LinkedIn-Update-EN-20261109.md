# LinkedIn update — KaiMau CHANG

Paste each block into the corresponding LinkedIn field. Experience titles and dates retain the established employment record.

## Headline

```text
Director | Technology Strategy & Scouting | Systems Architecture | Personal AI Hubs & Edge Ecosystems | From Hardware & Prototypes to Technology Roadmaps | U.S. Patent Co-inventor
```

## About

```text
I connect hands-on engineering with technology strategy—helping teams decide which technologies matter, how they fit into a system, and when to build, partner or license.

My foundation is a master’s degree in Electrical Engineering from National Chung Cheng University, focused on RF device R&D and IC design, including a dual-band Wi-Fi LNA.

My career has developed through four complementary stages:

• At Compal, I learned to get up to speed quickly on unfamiliar mobile platforms. Working with TI, EMP and Qualcomm taught me to recognize common principles, adapt my approach and become productive in a new architecture. Supporting Motorola also built my customer-facing engineering discipline.

• At Foxconn, I supported Tier-1 programs for Dell, HP, Sony and Nintendo, and provided factory-based NPI support for Apple programs. I learned to connect technical decisions with customer requirements, cross-functional execution and product delivery.

• At MediaTek, I developed internal innovation from system architecture analysis and technology selection to working prototypes, with exploration across VR/HMD and autonomous-vehicle technologies. I am a co-inventor on U.S. patent US9791924B2, filed during that period.

• At Huawei and Xunwei, my work broadened into cross-domain technology insight, pathfinding and actionable roadmaps.

At Xunwei, a biometric-sensing program brought that approach together: delivery in under 8 months against a 24-month internal R&D plan, supported by a 2-month clinical PoC, regional exclusivity and a 2-year runway for proprietary R&D.

Today, I focus on Personal AI Hubs, smart terminals and distributed edge-sensing ecosystems. I bring RF and hardware foundations, systems-level judgment, technology scouting and hypothesis-driven PoCs to Buy-then-Build decisions.

I value clear hypotheses, quantitative decision gates and collaboration that helps PM, engineering, procurement and legal teams move forward together.

Happy to connect on technology strategy, systems architecture and strategic R&D partnerships.
```

## Experience: XUNWEI Technologies Co. Ltd.
Title: Director | Technology Scouting and R&D Partnerships
Dates: Jan 2020 — Present

```text
Technology direction & strategic execution

• Led forward-looking technology scouting, competitive insight and roadmap planning for smart terminals, wearables and distributed edge sensing.

• Qualified external optical-sensing partners and completed a 2-month clinical PoC; delivered a biometric feature in under 8 months against a 24-month internal R&D plan.

• Planned a Buy-then-Build path with a 2-year proprietary R&D runway; worked with procurement and legal on regional exclusivity and balanced partnership terms.

• Used project-specific decision gates, pre-planned test hypotheses and cross-functional PM/engineering alignment to assess architecture trade-offs and R&D commitments.
```

## Experience: Huawei Technologies
Title: Technology Sourcing and Planning
Dates: Jan 2018 — Jan 2020

```text
Broader insight & technology pathfinding

• Broadened technology scanning across adjacent domains, turning industry signals into higher-level technical insights.

• Explored alternative technical paths and contributed to technology direction and roadmap planning beyond a single platform or product.
```

## Experience: MediaTek
Title: Technical Manager
Dates: Sep 2014 — Jan 2018

```text
Internal innovation, from architecture to prototype

• Developed internal innovation from system architecture analysis and technology identification through prototype implementation.

• Explored VR/HMD technologies across optics, ergonomics, ultrasound/ToF hand tracking, eye tracking and electromagnetic position tracking.

• Explored autonomous-vehicle architectures, sensing, drive-by-wire, datasets, simulation and data visualization.

• Co-inventor on U.S. patent US9791924B2, filed during my MediaTek tenure; listed in the inventor record as Kai-Mau Chang.
```

## Experience: Foxconn
Title: Senior EE/RF Engineer
Dates: Apr 2009 — Sep 2014

```text
Tier-1 customer delivery & factory NPI

• Supported Tier-1 customer programs for Dell, HP, Sony and Nintendo, developing customer-facing engineering and cross-functional coordination.

• Provided on-site factory NPI support for Apple customer programs.

• Worked across notebooks, netbooks, tablets, WLAN/Bluetooth modules, 60 GHz WiHD and NVIDIA LTE M.2 products.
```

## Experience: Compal
Title: Senior RF Engineer
Dates: Aug 2006 — Apr 2009

```text
Learning agility & adaptability

• Quickly learned and ramped up on TI, EMP and Qualcomm GSM/WCDMA platforms by finding common engineering principles and adapting to the differences in each architecture.

• Across my Compal roles, supported Motorola and strengthened customer-facing technical communication and the ability to apply prior learning in unfamiliar technical contexts.
```

## Experience: Compal
Title: RF Design Engineer
Dates: Aug 2004 — Aug 2006

```text
RF engineering foundations

• Worked on WCDMA mobile-phone RF design on the EMP platform, establishing hardware foundations for rapid learning in unfamiliar architectures and later system-level work.
```

## Skills — suggested priority

```text
Technology Strategy
Technology Scouting
Technology Roadmapping
Systems Architecture
RF Engineering
Wireless Communications
Product Development
Prototyping
Proof of Concept
New Product Introduction (NPI)
Technical Due Diligence
Strategic Partnerships
Cross-functional Collaboration
Spatial Computing
Sensor Fusion
Customer Engineering
Technology Risk Management
Adaptability
Learning Agility
```

## Education

```text
School: National Chung Cheng University
Degree: Master’s degree
Field of study: Electrical Engineering
Dates: 2003 – 2004

RF device research and development. Graduate IC design work included a dual-band Wi-Fi low-noise amplifier (LNA). Received high marks in multiple graduate IC tape-out evaluations.
```

## Patents

```text
Patent number: US9791924B2
Patent URL: https://patents.google.com/patent/US9791924B2/en
Contribution: Co-inventor
Inventor name in the record: Kai-Mau Chang

Co-inventor on U.S. patent US9791924B2, filed during my tenure at MediaTek. The inventor record lists me as Kai-Mau Chang.
```

## Patent reference — suitable for Featured

```text
US9791924B2 — U.S. Patent / Co-inventor
https://patents.google.com/patent/US9791924B2/en
```

## Featured — suggested links

```text
Personal portfolio
https://kelvin820.github.io

CEATEC 2026 industry report
https://kelvin820.github.io/reports/ceatec-2026/

WAIC 2026 industry report
https://kelvin820.github.io/reports/waic-2026/
```

## Projects — separate from professional reports

```text
Quiet Hours / 兩地之間
https://kelvin820.github.io/quiet_hours/

A two-city time and light experience combining local clocks, changing illustrations, 3D scenes and an immersive view.
```
